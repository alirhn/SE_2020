package com.alirhn.pokemones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
Button btnSignIn;
TextInputEditText etUser , etPass;
TextView signUp;
SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //remove status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN ,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        findView();
        sharedPreferences = getSharedPreferences("sharedName" , MODE_PRIVATE);

    }

    public void findView(){

        btnSignIn = findViewById(R.id.btnSignin);
        etUser = findViewById(R.id.etUserName);
        etPass = findViewById(R.id.etPassword);
        signUp = findViewById(R.id.tvSignup);
        onClick();
    }

    private void onClick() {

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this , Register.class);
                startActivity(i);
            }
        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn(etUser.getText().toString().trim() ,
                        etPass.getText().toString().trim());
            }
        public void signIn(String username , String password){
            String url = "https://pokemones.alirhn77.ir/login.php";
            ProgressDialog pdialog = new ProgressDialog(MainActivity.this);
            pdialog.setCancelable(false);
            pdialog.setMessage("please wait");
            pdialog.setTitle("connecting to server");
            pdialog.show();

            Response.Listener<String> listener = new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    pdialog.dismiss();
                    //Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_SHORT).show();
                    if (response.toString().trim().equals(etUser.getText().toString().trim())){
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("name" , etUser.getText().toString().trim());
                        editor.apply();
                        Intent i = new Intent(MainActivity.this , MainList.class);
                        Toast.makeText(MainActivity.this, "welcome"+response, Toast.LENGTH_SHORT).show();
                        startActivity(i);
                    }
                    else
                    {

                        Toast.makeText(MainActivity.this, "wrong username or password !", Toast.LENGTH_SHORT).show();

                    }
                }
            };

            Response.ErrorListener errorListener = new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    pdialog.dismiss();
                    Toast.makeText(MainActivity.this, "network issue", Toast.LENGTH_SHORT).show();
                }
            };
            StringRequest request = new StringRequest(Request.Method.POST ,
                    url , listener , errorListener){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String , String> hashMap = new HashMap<>();
                    hashMap.put("username" , username);
                    hashMap.put("password" , password);
                    return hashMap;
                }
            };
            MySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);
        }
        });
    }
}