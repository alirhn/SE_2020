package com.alirhn.pokemones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainList extends AppCompatActivity {
    RecyclerView recyclerView;
    PokemonesAdapter adapter;
    List<Pokemones> pokemonesList;
    private SliderLayout mDemoSlider;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_list);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN ,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);


        recyclerView = findViewById(R.id.recyMain);
        pokemonesList = new ArrayList<>();
        adapter = new PokemonesAdapter(this , pokemonesList);
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        getPokemons();
        mDemoSlider = findViewById(R.id.slider);

        setUpSlider();
    }

    private void setUpSlider() {
        HashMap<String, String> url_maps = new HashMap<String, String>();
        url_maps.put("lucario", "https://www.lefthudson.com/wp-content/uploads/2019/11/4k-pokemon-wallpaper-beautiful-pokemon-go-wallpapers-wallpapers-high-quality-for-you-of-4k-pokemon-wallpaper.jpg");
        url_maps.put("charmander", "https://wallpaperaccess.com/full/18953.jpg");
        url_maps.put("fire bird", "https://free4kwallpapers.com/uploads/originals/2016/08/04/pokemon-go-team-valor-team-red-4k-wallpaper.jpg");
        url_maps.put("zamazenta", "https://wallpaperaccess.com/full/24934.jpg");



        for (String name : url_maps.keySet()) {
            TextSliderView textSliderView = new TextSliderView(this);
            // initialize a SliderLayout
            textSliderView
                    .description(name)
                    .image(url_maps.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit)
                    ;

            //add your extra information
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra", name);

            mDemoSlider.addSlider(textSliderView);
            mDemoSlider.setCustomAnimation(new DescriptionAnimation());
            mDemoSlider.setDuration(4000);
        }
    }

    private void getPokemons(){
        String url = "https://pokemones.alirhn77.ir/a.json";
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("connecting");
        progressDialog.setMessage("listing the pokemones ");
        progressDialog.setCancelable(false);
        progressDialog.show();

        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {

                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0 ; i < jsonArray.length() ; i++){
                        JSONObject object = jsonArray.getJSONObject(i);
                        int id = object.getInt("#");
                        String name = object.getString("Name");
                        String type1 = object.getString("Type 1");
                        String type2 = object.getString("Type 2");
                        int total = object.getInt("Total");
                        int attack = object.getInt("Attack");
                        int defence = object.getInt("Defense");
                        int speed = object.getInt("Speed");
                        int generation = object.getInt("Generation");
                        String Legendary = object.getString("Legendary");
                        Pokemones pokes = new Pokemones(id , name , type1 , type2 ,
                                total , attack , defence , speed ,  generation , Legendary);
                        pokemonesList.add(pokes);
                        adapter.notifyDataSetChanged();

                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainList.this, "error", Toast.LENGTH_SHORT).show();
            }
        };
        StringRequest request = new StringRequest(Request.Method.GET , url , listener ,
                errorListener);
        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);
    }
}
