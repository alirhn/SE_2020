package com.alirhn.pokemones;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
TextInputEditText tvUser , tvPhone , tvPass , tvConfirmPass;
Button btnSignUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN , WindowManager.LayoutParams.FLAG_FULLSCREEN);

        findView();
        onClick();

    }

    private void onClick() {
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tvPass.getText().toString().trim().equals(tvConfirmPass.getText().toString().trim())){
                    signUp(tvUser.getText().toString().trim() , tvPass.getText().toString().trim() , tvPhone.getText().toString().trim());
                }
            }
        });

    }

    private void signUp(String username, String password, String phoneNumber) {

        String url = "https://pokemones.alirhn77.ir/register.php";
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                if (response.toString().trim().equals("201")){
                    Toast.makeText(Register.this, "this number is already signed up!", Toast.LENGTH_SHORT).show();
                   // progressDialog.dismiss();

                }
                else {
                    Toast.makeText(Register.this, "congratulations", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Register.this , MainActivity.class));
                }
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Register.this, "network issue", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();

            }
        };

        StringRequest request = new StringRequest(Request.Method.POST , url , listener , errorListener){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String , String > hashMap = new HashMap<>();
                hashMap.put("username" , username);
                hashMap.put("password" , password);
                hashMap.put("phone" , phoneNumber);
                return hashMap;
            }
        };
        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);

    }

    private void findView() {
        tvConfirmPass = findViewById(R.id.etConfirmPasswordRegister);
        tvPass = findViewById(R.id.etPasswordRegister);
        tvPhone = findViewById(R.id.etPhoneRegister);
        tvUser = findViewById(R.id.etUserNameRegister);
        btnSignUp = findViewById(R.id.btnSignUp);
    }
}