package com.alirhn.pokemones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Details extends AppCompatActivity {

String id , name , type1 , type2 , attack , defence , total , totalScore , speed , generation , legendary;
TextView tvname , tvType1 , tvType2 , tvAttack , tvDeffence , tvSpeed , tvTotal , tvGeneration , tvLegendary , tvComment;
RecyclerView recyclerView;
List<Comment> comments;
CommentAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN , WindowManager.LayoutParams.FLAG_FULLSCREEN);

        getValues();
        findView();
        setValues();
        getComments(id);
        onClick();





    }

    private void onClick() {
        tvComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Details.this , PostComment.class);
                i.putExtra("id" , id);
                startActivity(i);
            }
        });
    }

    private void getComments(final String commentId) {
        String url = "https://pokemones.alirhn77.ir/comment.php";
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONArray jsonArray = new JSONArray(response.toString());
                    for (int i = 0 ; i < jsonArray.length() ; i++){
                        JSONObject object = jsonArray.getJSONObject(i);
                        String description = object.getString("description");
                        String name = object.getString("name");
                        int rate = object.getInt("rate");
                        int commentId = object.getInt("commentId");

                        comments.add(new Comment(commentId , description , name , rate));
                        adapter.notifyDataSetChanged();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(Details.this, "network issue", Toast.LENGTH_SHORT).show();
            }
        };

        StringRequest request = new StringRequest(Request.Method.POST , url , listener , errorListener){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String , String> hashMap = new HashMap<>();
                hashMap.put("commentId" ,commentId);
                return hashMap;
            }
        };
        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);
    }

    private void setValues() {

        tvname.setText(name);
        tvLegendary.setText("legendary : " +legendary);
        tvGeneration.setText("generation : " +generation);
        tvTotal.setText("total Score : "+totalScore);
        tvType1.setText("type1 : "+type1);
        tvType2.setText("type2 : "+type2);
        tvAttack.setText("attack : "+attack);
        tvSpeed.setText("Speed : " +speed);
        tvDeffence.setText("defence : " +defence);

        comments = new ArrayList<>();
        adapter = new CommentAdapter(getApplicationContext() , comments);
        recyclerView.setLayoutManager(new LinearLayoutManager(this , RecyclerView.HORIZONTAL , false));
        recyclerView.setAdapter(adapter);
    }

    private void findView() {

        tvname = findViewById(R.id.tvNameDetail);
        tvType1 = findViewById(R.id.tvType1Detail);
        tvType2 = findViewById(R.id.tvType2Detail);
        tvAttack = findViewById(R.id.tvAttackDetail);
        tvDeffence = findViewById(R.id.tvDefenceDetail);
        tvSpeed = findViewById(R.id.tvSpeedDetail);
        tvTotal = findViewById(R.id.tvToTalDetail);
        tvGeneration = findViewById(R.id.tvGenerationDetail);
        tvLegendary = findViewById(R.id.tvLegendaryDetail);
        recyclerView = findViewById(R.id.recyclerComment);
        tvComment = findViewById(R.id.yourCommentTV);
    }

    private void getValues() {

        id = getIntent().getStringExtra("id");
        name = getIntent().getStringExtra("name");
        type1 = getIntent().getStringExtra("type1");
        type2 = getIntent().getStringExtra("type2");
        attack = getIntent().getStringExtra("attack");
        defence = getIntent().getStringExtra("defence");
        total = getIntent().getStringExtra("total");
        totalScore = getIntent().getStringExtra("totalScore");
        speed = getIntent().getStringExtra("speed");
        generation = getIntent().getStringExtra("generation");
        legendary = getIntent().getStringExtra("legendary");

    }


}