package com.alirhn.pokemones;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PokemonesAdapter extends RecyclerView.Adapter<PokemonesAdapter.MyViewHolder> {
    @NonNull
    Context context;
    List<Pokemones> pokemones;

    public PokemonesAdapter(@NonNull Context context, List<Pokemones> pokemones) {
        this.context = context;
        this.pokemones = pokemones;
    }

    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pokes
                , parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.bind(pokemones.get(position));
    }

    @Override
    public int getItemCount() {
        return pokemones.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvname, tvAttack, tvDefence, tvSpeed, tvGeneration, tvLegendery,
                tvTotalScore, tvType;
        CardView cardView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvAttack = itemView.findViewById(R.id.tvAtack);
            tvDefence = itemView.findViewById(R.id.tvDefense);
            tvGeneration = itemView.findViewById(R.id.tvGeneration);
            tvLegendery = itemView.findViewById(R.id.tvLegendry);
            tvname = itemView.findViewById(R.id.tvName);
            tvSpeed = itemView.findViewById(R.id.tvSpeed);
            tvTotalScore = itemView.findViewById(R.id.tvScore);
            tvType = itemView.findViewById(R.id.tvType);
            cardView = itemView.findViewById(R.id.card);
        }

        public void bind(Pokemones pokemon) {
            tvType.setText("type 1 : " + pokemon.getType1() + pokemon.getTypr2());
            tvname.setText(pokemon.getName());
            tvTotalScore.setText("total score : " + String.valueOf(pokemon.getTotalScore()));
            tvAttack.setText("attack : " + String.valueOf(pokemon.getAttack()));
            tvDefence.setText("defence : " + String.valueOf(pokemon.getDefence()));
            tvGeneration.setText("generation : " + String.valueOf(pokemon.getGeneration()));
            tvLegendery.setText("legendary : " + pokemon.getLegendary());
            tvSpeed.setText(String.valueOf("speed : " + pokemon.getSpeed()));

            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(PokemonesAdapter.this.context, Details.class);
                    i.putExtra("id", String.valueOf(pokemon.getId()));
                    i.putExtra("name", pokemon.getName());
                    i.putExtra("type1", pokemon.getType1());
                    i.putExtra("type2", pokemon.getTypr2());
                    i.putExtra("total", String.valueOf(pokemon.getTotal()));
                    i.putExtra("attack", String.valueOf(pokemon.getAttack()));
                    i.putExtra("defence", String.valueOf(pokemon.getDefence()));
                    i.putExtra("speed", String.valueOf(pokemon.getSpeed()));
                    i.putExtra("totalScore", String.valueOf(pokemon.getId()));
                    i.putExtra("generation", String.valueOf(pokemon.getId()));
                    i.putExtra("legendary", pokemon.getLegendary());

                    context.startActivity(i);
                }
            });

        }
    }
}
