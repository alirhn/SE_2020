package com.alirhn.pokemones;

public class Pokemones {
    int id;
    String name;
    String type1;
    String typr2;
    int total;
    int attack;
    int defence;
    int speed;
    int totalScore;
    int generation;
    String Legendary;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType1() {
        return type1;
    }

    public void setType1(String type1) {
        this.type1 = type1;
    }

    public String getTypr2() {
        return typr2;
    }

    public void setTypr2(String typr2) {
        this.typr2 = typr2;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefence() {
        return defence;
    }

    public void setDefence(int defence) {
        this.defence = defence;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    public int getGeneration() {
        return generation;
    }

    public void setGeneration(int generation) {
        this.generation = generation;
    }

    public String getLegendary() {
        return Legendary;
    }

    public void setLegendary(String legendary) {
        Legendary = legendary;
    }

    public Pokemones(int id, String name, String type1, String type2, int totalScore, int attack, int defence, int speed, int generation, String legendary) {
        this.id = id;
        this.name = name;
        this.type1 = type1;
        this.typr2 = type2;
        this.totalScore = totalScore;
        this.attack = attack;
        this.defence = defence;
        this.speed = speed;
        this.generation = generation;
        Legendary = legendary;
    }
}
