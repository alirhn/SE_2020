package com.alirhn.pokemones;

public class Comment {

    int pokId;
    String describe;
    String name;
    int rate;


    public int getPokId() {
        return pokId;
    }

    public void setPokId(int pokId) {
        this.pokId = pokId;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public Comment(int pokId, String describe, String name, int rate) {
        this.pokId = pokId;
        this.describe = describe;
        this.name = name;
        this.rate = rate;
    }
}
