package com.alirhn.pokemones;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class PostComment extends AppCompatActivity {
String id;
SharedPreferences sharedPreferences;
String namee;
EditText tvDesc;
RatingBar ratingBar;
Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN , WindowManager.LayoutParams.FLAG_FULLSCREEN);

        id = getIntent().getStringExtra("id");
        sharedPreferences = getSharedPreferences("sharedName" , MODE_PRIVATE);
        namee = sharedPreferences.getString("name" , "");
        //Toast.makeText(this, namee, Toast.LENGTH_SHORT).show();

        findView();
        onClick();


    }

    private void onClick() {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendComment(id , namee , tvDesc.getText().toString().trim() , ((int) ratingBar.getRating()));
                tvDesc.setText("");
                ratingBar.setRating(0);
                startActivity(new Intent(PostComment.this , MainList.class));
            }
        });
    }

    private void findView() {
        tvDesc = findViewById(R.id.etComment);
        ratingBar = findViewById(R.id.rateComment);
        button = findViewById(R.id.btnSendComment);


    }

    private void sendComment(String idd , String name , String describes , int rate ){

        String url = "https://pokemones.alirhn77.ir/sendComment.php";
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.show();

        Response.Listener<String> listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(PostComment.this, "1", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(PostComment.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        };

        StringRequest request = new StringRequest(Request.Method.POST , url , listener , errorListener){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String  , String> hashMap = new HashMap<>();
                hashMap.put("name" , name);
                hashMap.put("descr" , describes);
                hashMap.put("rate" , String.valueOf(rate));
                hashMap.put("commentId" , idd);
                return hashMap;
            }
        };

        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);

    }
}