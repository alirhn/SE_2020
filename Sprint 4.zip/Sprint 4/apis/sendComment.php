<?php

include "connect.php";

$name = $_POST["name"];
$desc = $_POST["descr"];
$rate = $_POST["rate"];
$id = $_POST["commentId"];

$sql2 ="INSERT INTO comment (name , describes , rate , commentId) 
          VALUES (:name , :desc , :rate , :ci)";
    
    $result1 = $conn->prepare($sql2);
    $result1->bindValue(":name" , $name);
    $result1->bindValue(":desc" ,$desc);
    $result1->bindValue(":rate" , $rate);
    $result1->bindValue("ci" , $id);
    $result1->execute();


?>