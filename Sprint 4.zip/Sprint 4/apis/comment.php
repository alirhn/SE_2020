<?php

include "connect.php";
$commentId = $_POST["commentId"];

$query = "SELECT * FROM comment WHERE commentId =:commentId";
$result = $conn->prepare($query);
$result->bindParam(":commentId" , $commentId);
$result->execute();
$output=array();
while ($row = $result->fetch(PDO::FETCH_ASSOC)){

    $record = array();
    $record["id"] = $row["id"];
    $record["description"] = $row["describes"];
    $record["name"] = $row["name"];
    $record["rate"] = $row["rate"];
    $record["commentId"] = $row["commentId"];
    $output[] = $record;

}

echo JSON_encode($output);


?>