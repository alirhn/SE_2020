<?php
include "connect.php";

$username = $_POST["username"];
$password = $_POST["password"];
$phone = $_POST["phone"];


$sql1 = "SELECT * FROM login WHERE phone =:phone";
$result = $conn->prepare($sql1);
$result->bindParam(":phone" , $phone);
$result->execute();
$row = $result->fetch();

if ($row>1){
    echo "201";
}else{

    $sql2 ="INSERT INTO login (username , password , phone) 
          VALUES (:username , :password , :phone )";

    $result1 = $conn ->prepare($sql2);
    $result1->bindParam(":username" , $username);
    $result1->bindParam(":password" , $password);
    $result1->bindParam(":phone" , $phone);
    $result1->execute();

    if ($result1){
        echo "202";
    }

}

?>